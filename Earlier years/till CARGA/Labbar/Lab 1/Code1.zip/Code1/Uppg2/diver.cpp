#include <iomanip>
#include <ios>
#include <sstream>

#include "diver.h"


//Overload operator>> to read data for a diver d from stream in
//If errors were encountered while reading the data for a diver d
//then d.name is set to an empty string
//Return the stream in
istream& operator>>(istream& in, Diver& d)
{
    //Add code

    return in;
}


//Calculate final score for diver d
//and store it in d.final_score
void calculate_final_score(Diver& d)
{
    //Add code
}


//Overload operator<< to write data for diver d
//to stream out: name and final score
void operator<<(ostream& out, const Diver& d)
{
    //Add code
}


//Overload comparison operator
//Return true if d1.final_score < d2.final_score
bool operator<(const Diver& d1, const Diver& d2)
{
    //Add code
    return false;
}

